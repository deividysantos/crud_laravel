<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('records', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('category_id');
            $table->string('description');
            $table->string('type',1);                //P - Pagar | R - Receber
            $table->date('release_date');            //Data de lançamento da conta
            $table->date('due_date')->nullable();    //Data de Vencimento da conta
            $table->date('payment_date')->nullable();//Data de pagamento da conta
            $table->decimal('amount');               //Valor da conta
            $table->foreign('category_id', 'categories_category_id_foreign')->references('id')->on('categories');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('records');
    }
};

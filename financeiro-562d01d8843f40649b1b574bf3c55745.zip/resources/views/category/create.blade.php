<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Financeiro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</head>
<body>
    <h1>Categorias - Novo Cadastro</h1>

    <div class="card" style="width: 50rem;">
        <div class="card-body">
            <form action="{{route('categoria.gravar')}}" method="post">
                @csrf
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Nome da Categoria</label>
                    <input type="text" name="description" class="form-control" id="exampleFormControlInput1" placeholder="Informe a Categoria">
                </div>
                <button type="submit" class="btn btn-success">Gravar</button>
                <a href="{{route('categoria.index')}}" type="button" class="btn btn-secondary">Voltar</a>
            </form>
        </div>
    </div>
</body>
</html>

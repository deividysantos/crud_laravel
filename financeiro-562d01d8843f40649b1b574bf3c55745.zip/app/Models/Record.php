<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Record extends Model
{
    use HasFactory;
    protected $table = 'records';
    protected $primaryKey = 'id';
    protected $fillable = [ 'category_id', 'description', 'type', 'release_date',
                            'due_date', 'payment_date', 'amount'];
}

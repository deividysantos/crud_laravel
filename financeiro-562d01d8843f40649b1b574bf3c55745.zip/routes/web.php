<?php

use App\Http\Controllers\CategoryController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
                    return view('welcome');
                });

Route::get('/categorias', [CategoryController::class, 'index'])->name('categoria.index');
Route::get('categorias/nova', [CategoryController::class, 'create'])->name('categoria.novo');
Route::post('categorias/nova', [CategoryController::class, 'store'])->name('categoria.gravar');




